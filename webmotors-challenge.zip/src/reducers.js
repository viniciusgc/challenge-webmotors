import { combineReducers } from "redux";
import makes from "./views/home/reducers";

export default combineReducers({ makes });
