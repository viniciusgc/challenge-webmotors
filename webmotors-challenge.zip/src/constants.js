export const API = {
  BASE: "http://desafioonline.webmotors.com.br",
  MAKE: "/api/OnlineChallenge/Make",
  MODEL: "/api/OnlineChallenge/Model",
  VERSION: "/api/OnlineChallenge/Version",
  VEHICLE: "/api/OnlineChallenge/Vehicles",
};
